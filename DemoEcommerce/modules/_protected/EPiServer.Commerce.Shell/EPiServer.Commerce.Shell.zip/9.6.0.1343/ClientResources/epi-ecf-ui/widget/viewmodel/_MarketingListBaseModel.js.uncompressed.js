﻿define("epi-ecf-ui/widget/viewmodel/_MarketingListBaseModel", [
// dojo
    "dojo/_base/declare",
// epi
    "epi/shell/TypeDescriptorManager",
// epi-cms
    "epi/shell/command/_CommandProviderMixin",
// epi-ecf-ui
    "../../MarketingUtils"
],
function (
// dojo
    declare,
// epi
    TypeDescriptorManager,
// epi-cms
    _CommandProviderMixin,
// epi-ecf-ui
    MarketingUtils
) {

    return declare([_CommandProviderMixin], {
        _getNameModel: function (item) {
            return {
                typeIdentifier: item.typeIdentifier,
                name: item.name,
                group: this._getPromotionGroup(item.typeIdentifier)
            };
        },

        _getItemType: function (typeIdentifier) {
            if (TypeDescriptorManager.isBaseTypeIdentifier(typeIdentifier, MarketingUtils.contentTypeIdentifier.salesCampaign)) {
                return this.itemType.campaign;
            }
            if (TypeDescriptorManager.isBaseTypeIdentifier(typeIdentifier, MarketingUtils.contentTypeIdentifier.promotionData)) {
                return this.itemType.promotion;
            }
            return this.itemType.notSet;
        },

        _getStatusModel: function (item) {
            var validFrom = new Date(item.properties.validFrom);
            var validUntil = new Date(item.properties.validUntil);

            return {
                status: item.properties.status,
                statusLabelKey: this._getStatus(item),
                validFrom: validFrom,
                validUntil: validUntil,
                typeIdentifier: item.typeIdentifier,
                campaignStatus: item.properties.campaignStatus,
                followsCampaignSchedule: item.properties.followsCampaignSchedule
            };
        },

        _getStatus: function (item) {
            return MarketingUtils.getStatusString(item.properties.status);
        },

        _getPromotionGroup: function (typeIdentifier) {
            if (TypeDescriptorManager.isBaseTypeIdentifier(typeIdentifier, MarketingUtils.contentTypeIdentifier.entryPromotion)) {
                return "entry";
            }
            if (TypeDescriptorManager.isBaseTypeIdentifier(typeIdentifier, MarketingUtils.contentTypeIdentifier.orderPromotion)) {
                return "order";
            }
            if (TypeDescriptorManager.isBaseTypeIdentifier(typeIdentifier, MarketingUtils.contentTypeIdentifier.shippingPromotion)) {
                return "shipping";
            }
            if (TypeDescriptorManager.isBaseTypeIdentifier(typeIdentifier, MarketingUtils.contentTypeIdentifier.promotionData)) {
                return "discount";
            }
            return null;
        }
    });
});