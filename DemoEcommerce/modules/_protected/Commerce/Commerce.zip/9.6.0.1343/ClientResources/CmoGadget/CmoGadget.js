require([
    "dojo/_base/lang",
    "dojo/on",
    "dojo/when",
    "epi",
    "epi/dependency",
    "epi/shell/TypeDescriptorManager",
    "epi/shell/widget/dialog/Dialog",
    "epi-cms/widget/ContentForestStoreModel",
    "epi-cms/widget/ContentSelectorDialog",
    "epi/i18n!epi/cms/nls/episerver.cms.widget.contentselector"
],

function (
    lang,
    on,
    when,
    epi,
    dependency,
    TypeDescriptorManager,
    Dialog,
    ContentForestStoreModel,
    ContentSelectorDialog,
    res
) {
    (function ($) {
        epi.CmoGadget = function () {
            function ProductBrowser(callbackArgument) {
                this.callbackArgument = callbackArgument;
            }

            ProductBrowser.prototype.CreateDialog = function() {

                var contentRepositoryDescriptors = dependency.resolve("epi.cms.contentRepositoryDescriptors"),
                    settings = contentRepositoryDescriptors["catalog"],
                    registry = dependency.resolve("epi.storeregistry"),
                    store = registry.get("epi.cms.content.light"),
                    model = new ContentForestStoreModel({
                        roots: settings.roots
                    }),
                    contentSelector = new ContentSelectorDialog({
                        canSelectOwnerContent: false,
                        showButtons: false,
                        roots: settings.roots,
                        multiRootsMode: true,
                        showRoot: true,
                        model: model,
                        allowedTypes: [
                                        "episerver.commerce.catalog.contenttypes.nodecontent",
                                        "episerver.commerce.catalog.contenttypes.productcontent",
                                        "episerver.commerce.catalog.contenttypes.variationcontent"
                        ],
                        value: this.callbackArgument.contentLink.value
                    }),
                    dialog = new Dialog({
                        title: res.title,
                        dialogClass: "epi-dialog-portrait",
                        content: contentSelector
                    });

                dialog.show();

                on(dialog, 'execute', lang.hitch(this, function() {
                    var contentLink = contentSelector.get("value");
                    if (!contentLink) {
                        return;
                    }
                    when(store.get(contentLink), lang.hitch(this, function(content) {
                        this.callbackArgument.code.value = content.properties["code"];
                        this.callbackArgument.name.value = content.name;
                        this.callbackArgument.contentLink.value = content.contentLink;
                        this.callbackArgument.isCategory.value = TypeDescriptorManager.isBaseTypeIdentifier(content.typeIdentifier, "episerver.commerce.catalog.contenttypes.nodecontent");
                    }));
                }));
            };

            // object returned by function. Exposes public methods and variables.
            var pub = {};
            pub.init = function (e, gadgetInstance) {
                // enable/disable buttons
                var setButtonStates = function () {
                    var value = $('td input:checkbox:checked', gadgetInstance.element).length == 0;
                    $('input[name=Delete]', gadgetInstance.element).attr('disabled', value);
                    var itemsCount = $('td input:checkbox:visible', gadgetInstance.element).length;
                    var itemsChkCount = $('td input:checkbox:checked', gadgetInstance.element).length;
                    if ((itemsCount == itemsChkCount) && (itemsCount != 0)) {
                        $("tr input[type=checkbox].clsCheckboxSelectAll", gadgetInstance.element).attr('checked', 'checked');
                    } else {
                        $("tr input[type=checkbox].clsCheckboxSelectAll", gadgetInstance.element).removeAttr('checked');
                    }
                };

                var viewLoaded = function (e, gadgetInstance) {
                    $("#pickerContainer input[name='browseButton']", gadgetInstance.element).bind('click', function () {
                        var callBackAgrument = {
                            name: $("#pickerContainer input[name='Name']", gadgetInstance.element)[0],
                            code: $("#pickerContainer input[name='Code']", gadgetInstance.element)[0],
                            isCategory: $("#pickerContainer input[name='IsCategory']", gadgetInstance.element)[0],
                            contentLink: $("#pickerContainer input[name='ContentLink']", gadgetInstance.element)[0],
                        };

                        var clb = new ProductBrowser(callBackAgrument);
                        clb.CreateDialog();
                    });
                    if (gadgetInstance.routeParams && gadgetInstance.routeParams.action == "Index") {
                        var currentGadgetID = '#' + $(gadgetInstance.element).attr('id');   // we have to take the ID as string because gadgetInstance.element is an array and cannot put as context of the below selector
                        // Check/Uncheck all checkboxes when user check select all 
                        $("tr input[type=checkbox].clsCheckboxSelectAll", currentGadgetID).live('click', function () {
                            if ($(this).is(':checked')) {
                                $('tr input[type=checkbox].clsCheckboxSelectMonitor', currentGadgetID).each(function () {
                                    $(this).attr('checked', 'checked').closest('tr').addClass('epi-selectedRow');
                                });
                            } else {
                                $('tr input[type=checkbox].clsCheckboxSelectMonitor', currentGadgetID).each(function() {
                                    $(this).removeAttr('checked').closest('tr').removeClass('epi-selectedRow');
                                });
                            }
                            setButtonStates();
                        });

                        // highlight selected rows
                        $('tr.clsCMOMonitorRow :checkbox', this).live('click', function () {
                            $(this).closest('tr').toggleClass('epi-selectedRow', $(this).is(':checked'));
                            setButtonStates();
                        });
                    }
                };

                // Listen to the loaded event raised each time a gadget view has been loaded
                $(this).bind("epigadgetloaded", viewLoaded);
            };

            return pub;
        } ();
    } (epiJQuery));
});