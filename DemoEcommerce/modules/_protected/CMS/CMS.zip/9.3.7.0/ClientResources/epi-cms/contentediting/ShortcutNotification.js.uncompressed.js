﻿define("epi-cms/contentediting/ShortcutNotification", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
// epi
    "epi/string",

    "epi-cms/contentediting/_ContentEditingNotification",
// resources
    "epi/i18n!epi/cms/nls/episerver.cms.contentediting.shortcutnotification"
],

function (
// dojo
    declare,
    lang,
// epi
    epiString,

    _ContentEditingNotification,
// resources
    resources
) {

    // linkTypes should match the EPiserver.Core.LinkTypes enum
    var linkTypes = ["normal",
                    "shortcut",
                    "external",
                    "inactive",
                    "fetchdata"];

    var ShortcutNotification = declare([_ContentEditingNotification], {
        // summary:
        //      Helper class to translate pageShortcutTypes
        //      into warning notifications for the notification bar.
        // tags:
        //      internal

        _onExecuteSuccess: function (/*Object*/value) {
            // summary:
            //      Update notification
            // tags:
            //      protected

            var shortcut = value.contentModel.get("iversionable_shortcut");
            if (shortcut) {
                this._updateNotification(shortcut.pageShortcutType);
            }

            if (this._contentModelWatch) {
                this._contentModelWatch.unwatch();
            }

            this._contentModelWatch = value.contentModel.watch("iversionable_shortcut", lang.hitch(this, function (name, oldValue, newValue) {
                this._updateNotification(newValue && newValue.pageShortcutType);
            }));
        },


        _updateNotification: function (shortcutType) {
            // summary:
            //      Maps the shortcutType enum value to a tranlated message
            // shortcutType: Number
            //      The value to set a message for
            // tags:
            //      private

            var shortcutName,
                message = null;

            if (shortcutType > 0) {
                shortcutName = linkTypes[shortcutType];
                message = epiString.toHTML(resources[shortcutName]);
            }

            this._setNotification({ shortcutType: shortcutType, content: message });
        }
    });

    ShortcutNotification.LinkTypes = linkTypes;

    return ShortcutNotification;

});
